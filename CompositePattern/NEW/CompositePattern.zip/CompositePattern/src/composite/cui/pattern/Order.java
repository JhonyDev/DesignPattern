package composite.cui.pattern;

public interface Order {
    void CalculatePrice();
}
