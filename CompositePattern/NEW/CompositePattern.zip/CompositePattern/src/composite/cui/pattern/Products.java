package composite.cui.pattern;

import java.util.ArrayList;
import java.util.List;

public class Products implements Order {
    private List<Order> childComponents = new ArrayList<Order>();

    public void add(Order component)
    {
        childComponents.add(component);

    }
    public void remove(Order component)
    {
        childComponents.remove(component);
    }

    @Override
    public void CalculatePrice() {
        for(Order component : childComponents)
        {
            component.CalculatePrice();
        }

    }
}
