package composite.cui.pattern;

public class Demo {
    public static void main(String[] args) {
        Boxes leaf1 = new Boxes("1");
        Boxes leaf2 = new Boxes("2");
        Boxes leaf3 = new Boxes("3");
        Boxes leaf4 = new Boxes("4");
        Boxes leaf5 = new Boxes("5");

        Products prod1 = new Products();
        prod1.add(leaf1);
        prod1.add(leaf2);

        Products prod2 = new Products();
        prod2.add(leaf3);
        prod2.add(leaf4);
        prod2.add(leaf5);

        prod1.add(prod2);
        prod1.CalculatePrice();
    }
}



