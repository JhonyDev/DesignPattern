package composite.cui.pattern;

public class Boxes implements Order {
    private String name;

    public Boxes(String name)
    {

        this.name = name;
    }

    @Override
    public void CalculatePrice() {
        System.out.println(name);
    }
}
